


// ____________________________ДЗ 1



// let fiboPoslid = (number) => {
//     let count1 = 0;
//     let count2 = 1;
//     console.log(count2);
//     for(let i = 1; i < number; i++){
//         count3 = count1+count2;
//         console.log(count3);
//         count1=count2;
//         count2=count3;
//     } 
// }
// fiboPoslid(5);

// ____________________________ДЗ 2

// let geoProg = (chislo,znamennik) =>{
//     let count = 1;
//     let sum = 1 ;
//     console.log(count);
//     for(let i = 1; i < chislo; i++ ){
//         count = count*znamennik;
//         sum = sum +count
//         console.log(count);

//     }
//     console.log(`Сумма чисел геометричної прогресії: ${sum}`);
// }
// geoProg(4,3)



// let geoProg = (chislo,znamennik) =>{
//     let b1 =1;
//     let q = znamennik;
//     let n =chislo;
//     let Sn = b1*(1-q**n)/(1-q);
//     console.log(Sn);
    
//     console.log(`Сумма чисел геометричної прогресії: ${Sn}`);
// }
// geoProg(4,3)


// ____________________________ДЗ 3




let start = +prompt("Перше число");
let end = +prompt("Останне число");
function someF(q,w) {
    for (let i = start; i <= end; i++) {
        let isPrime = true;
        for (let j = 2; j < i; j++) {
            if (i % j === 0) {
                isPrime = false;
            break;
            }
        }
        if (isPrime && i !== 1) {
            console.log(i);
        }     
    }
    2
    22
}
someF(start, end);















































